"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { ToastSuccess } from "@/components/ui/toast-success"

export default function Home() {
  const router = useRouter()
  const [email, setEmail] = useState("")
  const [showLogoutToast, setShowLogoutToast] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (email) {
      router.push("/login/name")
    }
  }

  // Move window access to useEffect to ensure it only runs in the browser
  useEffect(() => {
    // Check if user was redirected from logout
    const params = new URLSearchParams(window.location.search)
    if (params.get("logout") === "success") {
      setShowLogoutToast(true)
    }
  }, [])

  return (
    <div className="flex min-h-screen">
      {/* Left side - Form */}
      <div className="flex w-full flex-col items-center justify-center px-4 sm:px-6 md:w-1/2 lg:px-8 xl:px-12">
        <div className="w-full max-w-md">
          {showLogoutToast && (
            <ToastSuccess message="You have successfully logged out." onClose={() => setShowLogoutToast(false)} />
          )}

          {/* Logo */}
          <div className="mb-8 flex justify-center">
            <div className="relative h-16 w-16">
              <Image src="/logo.png" alt="Eryn Logo" fill className="object-contain" />
            </div>
          </div>

          <div className="text-center">
            <h2 className="text-2xl font-semibold text-gray-900">Welcome to eryn</h2>
            <p className="mt-2 text-gray-600">Log in to continue</p>
          </div>

          <form onSubmit={handleSubmit} className="mt-8 space-y-6">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                Email
              </label>
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-3 text-gray-900 placeholder-gray-400 focus:border-[#31E2EF] focus:outline-none focus:ring-1 focus:ring-[#31E2EF]"
                placeholder="name@email.com"
              />
            </div>

            <button
              type="submit"
              className="w-full rounded-md bg-[#182654] py-3 px-4 text-center font-medium text-white hover:bg-[#182654]/90 focus:outline-none focus:ring-2 focus:ring-[#182654] focus:ring-offset-2"
            >
              Continue with Email
            </button>
          </form>
        </div>
      </div>

      {/* Right side - Illustration */}
      <div className="hidden bg-gray-50 md:block md:w-1/2">
        <div className="flex h-full items-center justify-center">
          <Image
            src="/illustration.png"
            alt="Analytics Illustration"
            width={800}
            height={600}
            className="max-w-full"
            priority
          />
        </div>
      </div>
    </div>
  )
}
